define(['ojs/ojcore',"knockout","jquery","appController","ojs/ojconverterutils-i18n", "ojs/ojarraydataprovider",'ojs/ojknockout-keyset', "ojs/ojresponsiveutils", "ojs/ojresponsiveknockoututils", "ojs/ojknockout", "ojs/ojlistitemlayout", "ojs/ojtrain",
        "ojs/ojlistview","ojs/ojradioset","ojs/ojlabelvalue","ojs/ojlabel" ,"ojs/ojselectcombobox","ojs/ojbutton" ,"ojs/ojprogress-bar", "ojs/ojdatetimepicker", 'ojs/ojtable', 'ojs/ojswitch', 'ojs/ojvalidationgroup','ojs/ojselector','ojs/ojtoolbar','ojs/ojfilepicker','ojs/ojcheckboxset', "ojs/ojavatar","ojs/ojdrawerlayout"], 
function (oj,ko,$, app, ojconverterutils_i18n_1, ArrayDataProvider,  ojknockout_keyset_1,ResponsiveUtils, ResponsiveKnockoutUtils, AsyncRegExpValidator) {

    class RightToWorkViewModel {
        constructor(context) {
                var self = this;
                self.DepName = context.routerState.detail.dep_url;
                self.startOpened = ko.observable(true);
                self.startToggle = () => self.startOpened(!self.startOpened());
                var BaseURL = sessionStorage.getItem("BaseURL")
                self.groupValid = ko.observable();
                self.passportFileText = ko.observable('Passport');
                self.BRPFileText = ko.observable('BRP');
                self.passportCustomText = ko.observable('Please choose one');
                self.BRPCustomText = ko.observable('Please choose one');
                self.uploadDocumentMsg = ko.observable();
                self.dbsNumber = ko.observable();
                self.requiredDBS = ko.observable();  
                self.uploadError = ko.observable();
                self.choiceList = ko.observableArray([]);  
                self.choiceList.push(
                    {'value' : 'Yes', 'label' : 'Yes'},
                    {'value' : 'No', 'label' : 'No'},  
                );
                self.choiceListDP = new ArrayDataProvider(self.choiceList, {keyAttributes: 'value'});
                self.have_dbs = ko.observable();
                self.dbsSec = ko.observable();  
                self.dbs_expiry_date = ko.observable();
                self.update_expiry_date = ko.observable();
                self.ResultTitle = ko.observable('');
                self.progressDialog =ko.observable('Saving Right To Work Details')
                self.addRightToWorkMsg = ko.observable();  
                self.RightDet = ko.observableArray([]);
                self.RightActionBtn = ko.observable('Add');
                self.dbsStatus = ko.observable('');
                self.dbsFile = ko.observable('');
                self.updateFile = ko.observable('');
                
                self.visa_status = ko.observable();
                self.visaStatusList = ko.observableArray([]);
                self.visaStatusList.push(
                    {'value' : 'Dependant Visa', 'label' : 'Dependant Visa'},
                    {'value' : 'EU Settlement Scheme (EUSS)', 'label' : 'EU Settlement Scheme (EUSS)'},
                    {'value' : 'Graduate Visa', 'label' : 'Graduate Visa'},
                    {'value' : 'High Potential Individual (HPI) visa', 'label' : 'High Potential Individual (HPI) visa'},
                    {'value' : 'Not Applicable', 'label' : 'Not Applicable'},
                    {'value' : 'Other', 'label' : 'Other'},
                    {'value' : 'Right of Abode', 'label' : 'Right of Abode'},
                    {'value' : 'Start-up or Innovator Visa', 'label' : 'Start-up or Innovator Visa'},
                    {'value' : 'Student Visa', 'label' : 'Student Visa'},
                    {'value' : 'UK Ancestry visa', 'label' : 'UK Ancestry visa'},
                    {'value' : 'Work Visa', 'label' : 'Work Visa'}
                );
                self.visaStatusListDP = new ArrayDataProvider(self.visaStatusList, {keyAttributes: 'value'});
                self.visa_expiry_date = ko.observable();
                self.passport_no = ko.observable();
                self.place_of_issue = ko.observable();
                self.issue_date = ko.observable();
                self.expiry_date = ko.observable();  
                self.brp_expiry_date = ko.observable();
                self.have_sharecode = ko.observable();
                self.sharecode = ko.observable();
                self.passportShow = ko.observable();
                self.BRPShow = ko.observable();

                self.requiredContent = ko.observable();

                self.connected = function () {
                    if (sessionStorage.getItem("userName") == null) {
                        self.router.go({ path: 'signin' });
                    }
                    else {
                       app.onAppSuccess();
                       getRightToWorkData();
                    }
                };

                function getRightToWorkData(){
                    self.RightDet([]);
                    var BaseURL = sessionStorage.getItem("BaseURL")
                    $.ajax({
                        url: BaseURL + "/jpEditRightToWorkInfo",
                        type: 'POST',
                        data: JSON.stringify({
                            staffId : sessionStorage.getItem("staffId"),
                        }),
                        dataType: 'json',
                        timeout: sessionStorage.getItem("timeInetrval"),
                        context: self,
                        error: function (xhr, textStatus, errorThrown) {
                            if(textStatus == 'timeout' || textStatus == 'error'){
                                document.querySelector('#TimeoutSup').open();
                            }
                        },
                        success: function (data) {
                            console.log(data)
                             var result1 = JSON.parse(data[0]);
                             console.log(result1) 
                             var result2 = JSON.parse(data[1]);
                             console.log(result2) 
                             if(result1.length !=0){
                                self.RightActionBtn('Update')  
                                self.visa_status(result1[0][2])
                                self.visa_expiry_date(result1[0][3])
                                self.passport_no(result1[0][4])
                                self.place_of_issue(result1[0][5])
                                self.issue_date(result1[0][6])
                                self.sharecode(result1[0][7])
                                self.have_sharecode('Yes')
                                self.expiry_date(result2[0][6])
                                document.getElementById('passportPreview').style.display='block';
                                self.passportShow(result2[0][5])


                                if(result2.length ==2){
                                self.brp_expiry_date(result2[1][6])
                                document.getElementById('BRPPreview').style.display='block';
                                self.BRPShow(result2[1][5])

                                }


                               /*  
                                self.requiredDBS(true)
                                if(result[0][7] == "Pending") {
                                    self.dbsStatus('Pending');
                                }else if(result[0][7] == "Audited") {
                                    self.dbsStatus('Audited');
                                }   */

                            }  
                              
      
                        self.RightDet.valueHasMutated();
                        return self; 
                    }
                    })                
                }
                self.previewClick = function (event) {
                    document.getElementById("passportLink").href = self.passportShow()
                };

                self.previewClickBRP = function (event) {
                    document.getElementById("BRPLink").href = self.BRPShow()
                };

                self.rightToworkSection = function (event,data) {
                    if(self.visa_status()=='Not Applicable' || self.visa_status()=='Other'){
                        self.requiredContent(false)
                        self.uploadError('')
                    }else{
                        self.requiredContent(true) 
                        self.uploadError('*')
                    }
                   
                }
                self.shareCodeSec = function (event,data) {
                    if(self.have_sharecode()=='Yes'){
                        document.getElementById('sharecode_generator').style.display='none';
                    }else if(self.have_sharecode()=='No'){
                        document.getElementById('sharecode_generator').style.display='block';
                    }
                   
                }
              self.DBErrorOKClose = function (event) {
                document.querySelector('#openFileUploadResult').close();
                document.querySelector('#openAddRightToWorkResult').close();
            }; 

            self.passportSubmit = function (event,data) {
                self.uploadError('')
                var file = event.detail.files[0];
                //console.log(file)
                const result = event.detail.files;
                const files = result[0];
                var fileName= files.name;
                var uploadURL = BaseURL + "/css/uploads/";
                var filePath= uploadURL+fileName;
                //alert(self.movingFile_expiry_date())
                if(self.expiry_date() == undefined){
                    self.expiry_date('1990-01-01')
                } 
                //console.log(fileName)
                const reader = new FileReader();
                reader.readAsDataURL(files);
                
                reader.onload = ()=>{
                    document.querySelector('#openAddUploadingProgress').open();
                    self.uploadDocumentMsg('');
                    const fileContent = reader.result;
                    //console.log(fileContent)
                    $.ajax({
                        url: BaseURL + "/jpStaffFileUplaod",
                        type: 'POST',
                        data: JSON.stringify({
                            staffId : sessionStorage.getItem("staffId"),
                            file_name : fileName,
                            file : fileContent,
                            file_type : "Passport", 
                            file_type_additional : "Right To Work",
                            file_path : filePath,
                            expiry_date : self.expiry_date()
                        }),
                        dataType: 'json',
                        timeout: sessionStorage.getItem("timeInetrval"),
                        context: self,
                        error: function (xhr, textStatus, errorThrown) {
                            if(textStatus == 'timeout'){
                                document.querySelector('#openAddUploadingProgress').close();
                                document.querySelector('#Timeout').open();
                            }
                        },
                        success: function (data) {
                            console.log(data)
                            self.passportCustomText(fileName)
                            document.querySelector('#openAddUploadingProgress').close();
                            /* document.querySelector('#openFileUploadResult').open();
                            self.uploadDocumentMsg(data[0]); */
                        }
                    })      
                }
            }

            self.BRPSubmit = function (event,data) {
                var file = event.detail.files[0];
                //console.log(file)
                const result = event.detail.files;
                const files = result[0];
                var fileName= files.name;
                var uploadURL = BaseURL + "/css/uploads/";
                var filePath= uploadURL+fileName;
                if(self.brp_expiry_date() == undefined){
                    self.brp_expiry_date('1990-01-01')
                }                 
                //console.log(fileName)
                const reader = new FileReader();
                reader.readAsDataURL(files);
                
                reader.onload = ()=>{
                    document.querySelector('#openAddUploadingProgress').open();
                    self.uploadDocumentMsg('');
                    const fileContent = reader.result;
                    //console.log(fileContent)
                    $.ajax({
                        url: BaseURL + "/jpStaffFileUplaod",
                        type: 'POST',
                        data: JSON.stringify({
                            staffId : sessionStorage.getItem("staffId"),
                            file_name : fileName,
                            file : fileContent,
                            file_type : "BRP", 
                            file_type_additional : "Right To Work",
                            file_path : filePath,
                            expiry_date : self.brp_expiry_date()
                        }),
                        dataType: 'json',
                        timeout: sessionStorage.getItem("timeInetrval"),
                        context: self,
                        error: function (xhr, textStatus, errorThrown) {
                            if(textStatus == 'timeout'){
                                document.querySelector('#openAddUploadingProgress').close();
                                document.querySelector('#Timeout').open();
                            }
                        },
                        success: function (data) {
                            console.log(data)
                            self.BRPCustomText(fileName)
                            document.querySelector('#openAddUploadingProgress').close();
                            /* document.querySelector('#openFileUploadResult').open();
                            self.uploadDocumentMsg(data[0]); */
                        }
                    })      
                }
            }
                //Validation 
                self._checkValidationGroup = (value) => {
                    ////console.log(value)
                    var tracker = document.getElementById(value);
                    ////console.log(tracker.valid)
                    if (tracker.valid === "valid") {
                        return true;
                    }
                    else {
    
                        tracker.showMessages();
                        tracker.focusOn("@firstInvalidShown");
                        return false;
                    }
                };

            self.staffRightToWorkSave = function (event,data) {
                self.ResultTitle('Add Right To Work Details')
                if(self.visa_status() == undefined){
                    self.visa_status('')
                }
                if(self.visa_expiry_date() == undefined){
                    self.visa_expiry_date('1990-01-01')
                }
                if(self.passport_no() == undefined){
                    self.passport_no('')
                }
                if(self.place_of_issue() == undefined){
                    self.place_of_issue('')
                }
                if(self.issue_date() == undefined){
                    self.issue_date('1990-01-01')
                }
                if(self.sharecode() == undefined){
                    self.sharecode('')
                }
                var validSec = self._checkValidationGroup("staffRightToWorkCheck");  
                if (validSec && self.uploadError() =="") {
                    document.querySelector('#openAddRightToWorkProgress').open();
                     self.addRightToWorkMsg('');
                    $.ajax({
                        url: BaseURL+ "/jpStaffRightToWorkAdd",
                        type: 'POST',
                        data: JSON.stringify({
                            staffId : sessionStorage.getItem("staffId"),
                            visa_status : self.visa_status(),
                            visa_expiry_date : self.visa_expiry_date(),
                            passport_no : self.passport_no(),
                            place_of_issue : self.place_of_issue(),
                            issue_date : self.issue_date(),
                            sharecode : self.sharecode()
                        }),
                        dataType: 'json',
                        timeout: sessionStorage.getItem("timeInetrval"),
                        context: self,
                        error: function (xhr, textStatus, errorThrown) {
                            if(textStatus == 'timeout'){
                                document.querySelector('#openAddRightToWorkProgress').close();
                                document.querySelector('#Timeout').open();
                            }
                        },
                        success: function (data) {
                            document.querySelector('#openAddRightToWorkProgress').close();
                            document.querySelector('#openAddRightToWorkResult').open();
                            self.addRightToWorkMsg(data[0]);
                            console.log("Success")
                        }
                    })   
                }
          }

          self.staffDBSUpdate = function (event,data) {
            self.ResultTitle('Update DBS Details')
            var validSec = self._checkValidationGroup("dbsNumSec");  
            if (validSec && self.uploadError() == '') {
                document.querySelector('#openAddRightToWorkProgress').open();
                 self.addRightToWorkMsg('');
                $.ajax({
                    url: BaseURL+ "/jpUpdateDBSInfo",
                    type: 'POST',
                    data: JSON.stringify({
                        staffId : sessionStorage.getItem("staffId"),
                        dbs_number : self.dbsNumber(),
                    }),
                    dataType: 'json',
                    timeout: sessionStorage.getItem("timeInetrval"),
                    context: self,
                    error: function (xhr, textStatus, errorThrown) {
                        if(textStatus == 'timeout'){
                            document.querySelector('#openAddRightToWorkProgress').close();
                            document.querySelector('#Timeout').open();
                        }
                    },
                    success: function (data) {
                        document.querySelector('#openAddRightToWorkProgress').close();
                        document.querySelector('#openAddRightToWorkResult').open();
                        self.addRightToWorkMsg(data[0]);
                        console.log("Success")
                    }
                })   
            }
      }

      self.updateDBSStatus = function (event,data) {
        var BaseURL = sessionStorage.getItem("BaseURL")
        $.ajax({
            url: BaseURL+ "/jpStaffUpdateDBSStatus",
            type: 'POST',
            data: JSON.stringify({
                staffId : sessionStorage.getItem("staffId"),
            }),
            dataType: 'json',
            timeout: sessionStorage.getItem("timeInetrval"),
            context: self,
            error: function (xhr, textStatus, errorThrown) {
                if(textStatus == 'timeout'){
                    document.querySelector('#openUpdateStaffProgress').close();
                    document.querySelector('#Timeout').open();
                }
            },
            success: function (data) {
               console.log("Success")
               if(sessionStorage.getItem('section_status')=="Pending"){
                sessionStorage.setItem('dbs_status','Audited');
               }else if(sessionStorage.getItem('section_status')=="Audited"){
                sessionStorage.setItem('dbs_status','Pending');
               }
               location.reload();
            }
        })  

    }
            
            
          }
        }
            return  RightToWorkViewModel;

        });
